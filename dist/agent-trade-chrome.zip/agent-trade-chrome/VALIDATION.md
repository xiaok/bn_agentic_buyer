# Chrome 版验证记录

最近发布验证日期：2026-10-28。版本：0.1.3。早期页面和只读链上证据采集于 2026-10-25。

## 已通过

- `pnpm build`：生成完整 Manifest V3 浏览器包，没有 Node 运行时或本地服务依赖。
- `pnpm test`：58 项通过。涵盖原交易金额、报价、授权、退款、恢复逻辑，以及 URL / Flap Market 绑定、扩展消息边界、配对码、API 字段转换和 Chrome 日志的提交前持久化。包含二维码像素解码、快捷卖出的钱包归属，以及不确定提交不能显示成功的检查。
- 0.1.3 Gang：新增合并 Pad 的 V3 曲线识别、官方 Router 原生 BNB 买入、直接 Pad 卖出和按回执退款结算；修正旧 S 分支 9 字段 ABI 与分别取整的手续费。新增 8 项测试覆盖合约绑定错误、fair mint 拒绝、无 wrap / 授权的原生买入、退款 App 待确认后继续且不重复买入、卖出 50% 与精确授权、非 WBNB 路径和 Router 不可用时的 ERC20 路径。
- BOLT 主网只读：区块 130262268，识别 `merged-v3`、Pad `0x15CFD2dc8278Fb87a1783ef42111618E20874365`；构造 0.001 BNB 的 Router 调用，并通过公开 RPC `cast call` 返回非零代币数量。使用公开参考地址，不访问 Binance 会话，不签名、不广播。此为开发验证，实际下单仍跳过额外本地模拟。证据：`evidence/gang-merged-mainnet-readonly.json`，来源见 `../research/GANG-MERGED-VALIDATION.md`。未新增真实买卖验证。
- 0.1.3 编译包通过独立 Chrome 模拟订单回归：订单页与网页均正确显示待结算状态，主交易链接优先、未完成时保持锁且手动解锁可用；钱包网络请求和真实交易均为零。公开证据只保留合约地址与脱敏结果，不包含个人钱包、本机绝对路径或真实个人订单哈希。
- 0.1.2 合并 PR #1：主交易链接优先于授权链接；区分卖出已确认但 BNB 结算未完成；大订单号必须保持精度；顶层 / 子交易哈希冲突与不同历史接口之间的歧义均阻止误匹配。新增六项回归在合并前的 main 均失败，在 PR 中全部通过。
- 0.1.2 独立 Chrome 验证：订单页和网页悬浮面板均显示“卖出已确认／待结算”，主链接指向卖出交易而不是后来插入的授权；仍阻止未结算时新下单，并保留手动解锁。重新通过解锁确认 / 取消、刷新后保留状态与禁止恢复旧单的交互检查。证据：`evidence/settlement-ui-validation.json`、`settlement-status-dashboard.png`、`settlement-status-page.png` 及 `force-unlock-validation.json`。全部为模拟订单，没有钱包网络请求或实盘交易。
- 原 agent 的 22 项测试在本次发布中再次全部通过，原文件 SHA256 保持一致。
- 0.1.1 新增：手动解锁须显式确认，完整保留原提交证据，禁止恢复和重放旧单；存储失败不放开锁，解锁与恢复互斥，超过十二条记录的待处理订单仍可见。历史查询校验官方参数、游标分页、`orderId` / `binanceTxId` 精确匹配，并在恢复时核对真实调用而非误认授权哈希。
- 独立 Chrome 模拟订单回归：取消解锁确认时仍保持锁，确认后买卖按钮恢复，解锁本身不产生任何网络请求；刷新后状态保留，恢复旧单被拒绝，新操作能创建。证据：`evidence/force-unlock-validation.json`、`force-unlock-before.png`、`force-unlock-after.png`。没有访问真实钱包或发出真实交易。
- 独立 Chrome 配置中的模拟初始化：生成六位配对码、轮询确认、读取钱包地址和 Developer Mode、保存并复用会话。页面重新打开不会重复登录。
- 扫码界面回归：实际 Chrome canvas 像素可解码为原始登录链接；待扫码时重开页面恢复原二维码，不重复登录；过期后隐藏二维码并提示重连；模拟连接成功后隐藏配对区。证据：`evidence/pairing-qr-validation.json`、`pairing-qr.png`（模拟二维码）。
- 浏览器点击回归：真实鼠标点击触发一次操作，脚本合成 click 被忽略，双击不会创建两个进行中的操作，同一 UUID 重放不会生成新订单。Flap 卡片按其精确 Market key 创建操作。模拟 RPC 在任何授权 / preview / execute 前停止。
- 新交互 Chrome 回归：网页显示买入失败 / 成功提示与交易链接；订单页按该行地址请求卖出 50% / 全部，即使输入框是另一个地址；双击只生成一笔操作，进行中禁用其他卖出按钮；网页面板和订单页的平台链接均正确。全部为模拟订单，证据：`evidence/feedback-validation.json`、`buy-success-notice.png`、`order-quick-sell.png`。
- 使用本地 HTTPS 服务与实际 Chrome 网络栈验证 Cookie：捕获 Set-Cookie、只给扩展自己的下一次 API 请求注入该会话、浏览器普通 Cookie jar 保持不变。没有请求 Binance。
- 三个真实公开网站的只读页面检查：Four preset 列表、Flap 卡片与详情、Gang 列表均出现按钮，所显示地址与对应 token / Market 一致。此检查的钱包网络请求被阻断，显示的是测试会话外观。
- 原 agent 目录与交付前保存的 SHA256 清单一致，与此前交付 `dist/agent-trade.zip` 的对应文件逐字节相同。旧 ZIP 的 SHA256：`27562dc0a49c90a431d96b58450c9fd68921947187246d1033dfd88e62203037`。

证据在源码项目的 `evidence/browser-validation.json`、`cookie-validation.json`、`live-page-bindings.json`、`engine-readonly.json` 及页面截图中。页面条目和数量会随网站更新变化，截图不是行情承诺。

## 用户环境中的真实买入

用户自行连接钱包并点击买入后，扩展订单显示 `SUCCESS`；曾通过公开 BSC RPC 只读核对成功回执及代币转入日志。为保护隐私，公开版本不记录个人钱包、交易哈希、精确区块、数量与持仓。该检查没有代用户发送任何交易。

## 尚未验证

上述一笔交易不能覆盖三个平台的全部内盘 / 外盘、卖出、资金兑换、断线恢复或 App 风控分支；这些仍未全面实盘验证。此次新增的快捷卖出与提示使用模拟订单测试，没有额外真实下单。Binance CLI 的 HTTP 协议移植尚不是官方浏览器 SDK；服务端可能因客户端、接口变化、地区或账号设置拒绝请求。

原 agent 文件保持不变，不代表两个独立客户端在同一钱包上并发下单具有共享的本地锁；这两个版本不共享操作日志。

默认配置为 0.001 BNB、交易 / 资金兑换各 100 bps 滑点，链上 gas 另计。跳过额外本地试买，保留 BAW preview。
